# Guía de Deployment - LangMind v2

## PASO 1: Push a GitHub (2 minutos)

### Opción A: Generar nuevo token
1. Ve a https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Scopes: `repo`
4. Copy el token

5. Usa el nuevo token:
```bash
git remote set-url origin "https://TOKEN@github.com/laitnlagency-cpu/lang-app.git"
git push -u origin main
```

### Opción B: Push manual por browser
1. Ve a https://github.com/laitnlagency-cpu/lang-app
2. Click "Add file" → "Upload files"
3. Copia todos los archivos del proyecto
4. Commit con mensaje: "feat: audio, multi-idioma, onboarding"

---

## PASO 2: Configurar Supabase (5 minutos)

1. Ve a https://supabase.com/dashboard
2. Abre tu proyecto LangMind
3. SQL Editor → New Query
4. Copia todo el contenido de `schema-updated.sql`
5. Ejecuta

**Esperado:** ✓ Tablas creadas (user_preferences, interactions, feedback)

---

## PASO 3: Configurar Vercel (5 minutos)

1. Ve a https://vercel.com/dashboard
2. Click "Import Project"
3. Elige el repositorio: `laitnlagency-cpu/lang-app`
4. Click "Import"

### Environment Variables

En Vercel → Project Settings → Environment Variables, agrega:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
OPENAI_API_KEY=sk-...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_...
STRIPE_SECRET_KEY=sk_...
STRIPE_WEBHOOK_SECRET=whsec_...
NEXT_PUBLIC_APP_URL=https://your-vercel-url.vercel.app
```

5. Click "Deploy"

**Esperado:** Deploy exitoso en 3-5 minutos ✓

---

## PASO 4: Configurar OAuth Google (3 minutos)

### En Supabase:
1. Authentication → Providers → Google
2. Enable
3. Copy Client ID + Secret

### En Google Cloud:
1. https://console.cloud.google.com/apis/credentials
2. OAuth 2.0 Client ID → Edit
3. Authorized redirect URIs, agrega:
   - `https://your-project.supabase.co/auth/v1/callback`
   - `https://your-vercel-url.vercel.app/auth/callback`
4. Save

---

## PASO 5: Verificar Deploy (2 minutos)

1. Abre tu URL de Vercel: `https://your-project.vercel.app`
2. Click "Comenzar con Google"
3. Elige Español → Inglés
4. Haz click en Lección 1
5. Prueba 🔊 (audio)
6. Prueba 🎤 (pronunciación)
7. Escribe algo en el chat

**Esperado:**
- ✓ OAuth funciona
- ✓ Audio se escucha
- ✓ Micrófono graba
- ✓ IA responde

---

## PASO 6: Verificar Stripe (3 minutos)

1. Dashboard → Click "Suscribirse"
2. Click botón "Suscribirse Ahora"
3. Debería ir a Stripe (en test mode)
4. Usa tarjeta de prueba: `4242 4242 4242 4242`

**Esperado:** ✓ Redirige a dashboard después del pago

---

## 📊 Métricas Esperadas

| Métrica | Esperado |
|---------|----------|
| Landing | Carga en <1s |
| Auth | <2s con Google |
| Dashboard | Muestra idiomas seleccionados |
| Lección | Audio funciona en 100% |
| Chat IA | Responde en <3s |
| Premium | Gate bloquea lección 4 |

---

## 🐛 Troubleshooting

### "Module not found"
```bash
cd /tmp/lang-app
npm install
npm run build
```

### Audio no funciona
- Chrome/Edge necesario (Safari = pronunciación sin grabación)
- Permitir micrófono en navegador settings

### IA no responde
- Verificar `OPENAI_API_KEY` en Vercel
- Probar en local: `npm run dev`

### OAuth no redirige
- Verificar redirect URLs en Google Cloud
- Check `NEXT_PUBLIC_APP_URL` en Vercel

---

## ✅ Checklist Final

- [ ] Token generado + push a GitHub
- [ ] Supabase schema ejecutado
- [ ] Vercel deploy exitoso
- [ ] Google OAuth configurado
- [ ] Audio funciona
- [ ] IA tutora responde
- [ ] Premium gate funciona

---

**Tiempo total:** ~20 minutos
**Status:** Listo para usar en producción

**¿Dudas?** laitnl.agency@gmail.com
